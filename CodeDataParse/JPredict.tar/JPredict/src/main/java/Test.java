class Test {
    void fooBar() {
        System.out.println("http://github.com");
    }
}